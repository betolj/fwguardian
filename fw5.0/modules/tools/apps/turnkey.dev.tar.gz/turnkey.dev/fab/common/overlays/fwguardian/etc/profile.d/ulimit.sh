#!/bin/bash
ulimit -n 30000 2>/dev/null
