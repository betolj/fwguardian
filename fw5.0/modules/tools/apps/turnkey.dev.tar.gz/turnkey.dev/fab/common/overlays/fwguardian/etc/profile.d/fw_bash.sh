#!/bin/bash

alias rm="rm -i"
alias cp="cp -i"
alias mv="mv -i"

alias joe="/usr/bin/joe -nobackups"

alias l="ls -laF --color=auto"
alias log="cd /var/log/ && ls"
alias tm="tail -f /var/log/messages"

export EDITOR=vim
